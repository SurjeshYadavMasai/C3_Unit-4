const app = require("./index");
const mongooseConnect = require("./confi/database");

app.listen(7200, async () => {
  try {
    await mongooseConnect();
    console.log("listening at ", 7200);
  } catch (err) {
    return send(err.message);
  }
});
