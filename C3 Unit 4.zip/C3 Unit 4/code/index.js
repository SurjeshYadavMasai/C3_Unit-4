const express = require("express");

const userController = require("./control/user");
const bookController = require("./control/book");
const publicController = require("./control/public");
const commentController = require("./control/comment");

const app = express();

app.use(express.json());

app.use("/users", userController);
app.use("/book", bookController);

app.use("/public", publicController);

app.use("/comment", commentController);

module.exports = app;
